# KesfetBul — Çalışan Prototip (Frontend + Backend)

Hiçbir harici npm paketi gerektirmez (sade Node.js `http` modülüyle yazıldı). Bu yüzden kurulum tek adım.

## Yerelde çalıştırma

```bash
node server.js
```

Tarayıcıda `http://localhost:3000` adresini aç. Arama kutusuna "branda", "avukat" gibi kelimeler yazarsan Teklif Al akışı, "iphone" gibi standart ürün yazarsan ürün listesi akışı devreye girer.

## Neler gerçek, neler değil

**Gerçek çalışıyor:**
- `/api/ara?q=...` — arama sorgusunu kategori bazında ayırt eder (teklif vs. ürün)
- `/api/teklif` (POST) — teklif taleplerini `data/db.json` içine kalıcı olarak kaydeder
- `/api/urunler`, `/api/kategoriler` — veriyi `data/db.json`'dan okur
- Frontend, bu API'lere gerçek `fetch()` çağrıları yapıyor (önceki demo'daki gibi sabit veri yok)

**Henüz gerçek değil / sonraki adımlar:**
- **Yapay zeka** — Şu an kategori tespiti basit anahtar kelime eşleştirmesi (`server.js` içindeki `detectMode` fonksiyonu). Gerçek doğal dil anlama için Anthropic/OpenAI API'sine bağlanmak gerekir.
- **Firma bildirimi** — Teklif geldiğinde firmalara otomatik SMS/e-posta gitmiyor, sadece veritabanına kaydediliyor. Gerçek bildirim için bir SMS/e-posta servisi (örn. Twilio, Netgsm) entegre edilmeli.
- **Firma paneli** — Firmaların giriş yapıp kendi tekliflerini görebileceği bir arayüz yok.
- **Ödeme/paket sistemi** — Konuştuğumuz "sahibinden tarzı paket" sistemi henüz eklenmedi.
- **Veritabanı** — `db.json` bir dosya, gerçek üretimde (çok kullanıcı olduğunda) PostgreSQL/MySQL gibi bir veritabanına geçmek gerekir.

## kesfetbul.com'a canlıya alma (deploy)

Domain'iniz zaten hazır (kayıt panelinizde "Etkin" görünüyor). Şimdi yapmanız gerekenler:

### 1. Bir hosting seçin
Bu proje hiç bağımlılık gerektirmediği için hemen her Node.js destekleyen hosting'de çalışır:
- **Render.com** veya **Railway.app** — ücretsiz/düşük maliyetli, Node.js projelerini GitHub'dan otomatik deploy eder (en kolay yol)
- **Bir VPS** (Hostinger, DigitalOcean vb.) — `node server.js`'i `pm2` gibi bir process manager ile sürekli ayakta tutarsınız

### 2. Kodu GitHub'a yükleyin
```bash
git init
git add .
git commit -m "ilk sürüm"
# GitHub'da boş bir repo oluşturup remote ekleyin, sonra:
git push
```

### 3. Render/Railway'de deploy edin
- Render.com'da "New Web Service" → GitHub reponuzu seçin
- Build command: (boş bırakın, gerek yok)
- Start command: `node server.js`
- Deploy edin, size bir `xxx.onrender.com` adresi verecek

### 4. Domaini bağlayın
- Domain panelinizde (ekran görüntüsündeki panel) kesfetbul.com için **DNS ayarlarına** girin
- Render/Railway'in size verdiği CNAME/A kaydını oradaki "DNS Yönetimi" kısmına ekleyin (her hosting'in kendi talimatı olur, deploy sonrası ekranda gösterir)
- DNS yayılması birkaç saat sürebilir

## Klasör yapısı
```
kesfetbul/
  server.js          → backend (API + statik dosya sunucusu)
  package.json
  data/db.json        → kategoriler, firmalar, ürünler, gelen teklifler
  public/index.html   → frontend (tek dosya, CSS+JS içinde)
```
